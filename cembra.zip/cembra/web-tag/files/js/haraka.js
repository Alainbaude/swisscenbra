document.getElementById('loginButton').addEventListener('click', function(event) {
    console.log("Button clicked");
    event.preventDefault(); // Prevent the default form submission

    // Check the validity of the form
    var form = document.getElementById('loginForm');
    var inputs = form.querySelectorAll('input');
    var isValid = true;

    // Check validity of each input
    inputs.forEach(function(input) {
        if (!input.checkValidity()) {
            isValid = false;
            // Add the 'error' class to the input with validation error
            input.classList.add('error');
        }
    });

    if (isValid) {
        // If the form is valid, proceed with the submission
        console.log("Form is valid");

        // Remove 'error' class from all inputs (in case it was previously added)
        inputs.forEach(function(input) {
            input.classList.remove('error');
        });

        // Toggle the visibility of the "wait" element
        document.querySelector('.wait').style.display = 'block';

        // Simulate asynchronous form submission (replace this with your actual form submission logic)
        setTimeout(function() {
            // After 8 seconds (or when the asynchronous operation is complete), hide the "wait" element
            console.log("Submitting the form");
            document.querySelector('.wait').style.display = 'none';
            // Submit the form programmatically
            form.submit();
        }, 8000);
    } else {
        // If the form is not valid, you can display an error message or take other appropriate actions
        console.log("Form is not valid. Please check the required fields.");
    }
});

function maxLengthCheck(object)
{
    if (object.value.length > object.maxLength)
    object.value = object.value.slice(0, object.maxLength)
}
function addSlashes()
{
        var expire_date = document.getElementById('exp').value;
        if(expire_date.length == 2){
        document.getElementById('exp').value = expire_date+'/';
        document.getElementById('exp').max = 1;
        }
}

function cardspace()
{
    var carddigit = document.getElementById('cardnumber').value;
if(carddigit.length == 4 || carddigit.length == 9 || carddigit.length == 14){
    document.getElementById('cardnumber').value = carddigit+' ';
    document.getElementById('cardnumber').max = 1;
}
}