<?php

// 
// tg : https://t.me/spartanwarriorz

define("TOKEN", '7174399921:AAHZVK6f6wjeRtgJPPtGgl_WgjhuKq1YA4E');
define("CHATID", '5526121481');

$get_notification = "yes";
